"use client";

import useEmblaCarousel from "embla-carousel-react";
import { useCallback, useEffect, useState } from "react";
import ProductCard from "@/components/products/ProductCard";
import { products } from "@/data/products";

export default function FeaturedProductsCarousel() {
  const [emblaRef, emblaApi] = useEmblaCarousel({
    align: "center",
    loop: true,
    dragFree: false,
    skipSnaps: false,
  });

  const [selectedIndex, setSelectedIndex] = useState(0);

  const updateCarouselState = useCallback(() => {
    if (!emblaApi) return;
    setSelectedIndex(emblaApi.selectedScrollSnap());
  }, [emblaApi]);

  useEffect(() => {
    if (!emblaApi) return;

    const frame = requestAnimationFrame(() => {
      updateCarouselState();
    });

    emblaApi.on("select", updateCarouselState);
    emblaApi.on("reInit", updateCarouselState);

    return () => {
      cancelAnimationFrame(frame);
      emblaApi.off("select", updateCarouselState);
      emblaApi.off("reInit", updateCarouselState);
    };
  }, [emblaApi, updateCarouselState]);

  const scrollPrev = useCallback(() => {
    emblaApi?.scrollPrev();
  }, [emblaApi]);

  const scrollNext = useCallback(() => {
    emblaApi?.scrollNext();
  }, [emblaApi]);

  return (
    <section className="bg-background px-6 py-8 md:py-10">
      <div className="mx-auto max-w-4xl">
        <div className="mb-6 flex items-end justify-between gap-6">
          <div>
            <p className="font-display text-lg tracking-[0.08em] text-olive">
              PRODUCTOS DESTACADOS
            </p>
            <h2 className="mt-1 text-2xl font-bold text-foreground md:text-3xl">
              Una pieza cada vez
            </h2>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={scrollPrev}
              aria-label="Producto anterior"
              className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-border bg-card text-foreground shadow-sm transition duration-300 hover:-translate-y-0.5 hover:border-foreground"
            >
              ←
            </button>

            <button
              type="button"
              onClick={scrollNext}
              aria-label="Siguiente producto"
              className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-border bg-card text-foreground shadow-sm transition duration-300 hover:-translate-y-0.5 hover:border-foreground"
            >
              →
            </button>
          </div>
        </div>

        <div className="mx-auto max-w-[380px]">
          <div ref={emblaRef} className="overflow-hidden">
            <div className="-ml-5 flex">
              {products.map((product) => (
                <div
                  key={product.id}
                  className="min-w-0 shrink-0 pl-5"
                  style={{ flex: "0 0 100%" }}
                >
                  <ProductCard product={product} />
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-5 flex items-center justify-center gap-2">
          {products.map((product, index) => (
            <button
              key={product.id}
              type="button"
              onClick={() => emblaApi?.scrollTo(index)}
              aria-label={`Ir al producto ${index + 1}`}
              className={`h-2 rounded-full transition-all duration-300 ${
                selectedIndex === index
                  ? "w-7 bg-foreground"
                  : "w-2 bg-border hover:bg-muted"
              }`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
